<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CilOrderRequestSet extends Model
{
    use HasFactory;

    protected $table = 'CILORDERREQUESTSET';
    public $timestamps = false;
}
