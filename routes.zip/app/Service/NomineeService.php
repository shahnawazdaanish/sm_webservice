<?php

namespace App\Service;

use App\Entity\CILorderRequest;
use App\Entity\CILOrderRequestResponse;
use App\Entity\CILOrderResponse;
use App\Models\CilOrderRequestSet;

class NomineeService
{
    public function hello(string $name): string
    {
        return 'Hello, ' . $name;
    }

    public function OrderRequest(array $OrderRequests)
    {

    }

    public function OrderRequests(array $OrderRequests)
    {

    }

    public function CILorderRequest($request): CILOrderRequestResponse
    {
        /** @var CILorderRequest $CILorderRequest */
        $CILorderRequest = $this->objectToObject($request->Request, CILorderRequest::class);

        $dbCil = new CilOrderRequestSet();
        $dbCil->REQUESTID = $CILorderRequest->getRequestID();
        $dbCil->ORDERID = $CILorderRequest->getOrderID();
        $dbCil->save();

        $cilResponse = new CILOrderResponse();
        $cilResponse->setStatus(true);
        $cilResponse->setErrorCode(0);
        $cilResponse->setRequestID($CILorderRequest->getRequestID());

        $cilRequestResponse = new CILOrderRequestResponse();
        $cilRequestResponse->setReturn($cilResponse);
        return $cilRequestResponse;
    }


    public function arrayToObject(array $array, $className) {
        return unserialize(sprintf(
            'O:%d:"%s"%s',
            strlen($className),
            $className,
            strstr(serialize($array), ':')
        ));
    }

    function objectToObject($instance, $className) {
        return unserialize(sprintf(
            'O:%d:"%s"%s',
            strlen($className),
            $className,
            strstr(strstr(serialize($instance), '"'), ':')
        ));
    }
}
