<?php

namespace App\Service\Converter;

interface ConverterServiceInterface
{
    public function convert($request);
}
